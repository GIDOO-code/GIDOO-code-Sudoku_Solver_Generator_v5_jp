﻿using System;
using System.IO;
using static System.Math;
using static System.Diagnostics.Debug;


using GIDOO_space;
using System.Text;
using System.Linq;
using System.Collections.Generic;

namespace GNPXcore{
    using pRes=Properties.Resources;
    using sysWin=System.Windows;

    // [ToDo] Run in unit test project.


    public partial class NuPz_Win{   

        private void GNPX_unitTest( bool testB ){
            if( !testB )  return;
            GNPZExtender.UInt128_test();
            ULogical_Node.ULgElement_test( ); // ULogical_Node
			ULogical_4_GN.ULogical_4_GN_test( );
        }

        public void GNPX_Develop_prepare( GNPX_App GNPX_000 ){
            if( !File.Exists( GNPX_000._Develop_SuDoKuName) ) return;
            try{
                using( var fpR=new StreamReader( GNPX_000._Develop_SuDoKuName) ){
                    string LRecord = fpR.ReadLine();
                    if( LRecord is null ) return;
                    string st = LRecord.Replace(" ","").Replace(".","0");

                    List<UCell> B = new List<UCell>();
                    int rc=0;
                    for(int k=0; rc<81; ){
                        if(st[k]=='+'){ k++; B.Add(new UCell(rc++,-( st[k++].ToInt())) ); }
                        else{
                            while(!st[k].IsNumeric()) k++;
                            B.Add( new UCell(rc++, st[k++].ToInt() ) );
                        }
                    }
                    GNPX_000._Develop_Puzzle = B;
                }
            }
            catch( Exception e ){ WriteLine( $"{e.Message}\r{e.StackTrace}" ); }
        }

    }
}