using System;
using System.Collections.Generic;
using System.Linq;
using System.Diagnostics;
using System.Windows.Media;

using static System.Diagnostics.Debug;
using static System.Math;

using GIDOO_space;



namespace GNPXcore{
    public partial class GNPZ_Engin{                        // This class-object is unique in the system.

        private Research_trial_Simple TandE;

		public  string      TandE_st_Puzzle="";

        private int[]		sol_int81;
		public  string      TandE_st_sol_int81="";
        public string       Result{   get=>pPZL.Sol_Result; set=>pPZL.Sol_Result=value; }
        public string       ResultLong{   get=>pPZL.Sol_ResultLong; set=>pPZL.Sol_ResultLong=value; }

		public string       extResult{   get=>pPZL.extResult; set=>pPZL.extResult=value; }
        public void DebugSolCheck_Set( bool solveB=true ){
            TandE = null;

#if DEBUG
			solveB = true;
#endif

			if( solveB ){
				List<int> intBoard = pBOARD.ConvertAll( P=> Max(P.No,0) );
				TandE_st_Puzzle = string.Join("",intBoard);

				TandE = new Research_trial_Simple( intBoard );

					Stopwatch sw = new Stopwatch();
					sw.Start();
				bool SolCode = TandE.TrialAndErrorApp();
					var elps = sw.ElapsedMilliseconds;

				if(SolCode)  sol_int81 = TandE.Sol.ToList().ConvertAll(p=>Abs(p)).ToArray();

				TandE_st_sol_int81 = string.Join("",sol_int81);
				WriteLine( $"{TandE_st_sol_int81} ... elapsed time:{elps}ms" );
			}

        }

        public bool DebugSolCheck_Check(){
            if( TandE is null )  return false;;
            bool errorB = false;
            for( int k=0; k<81; k++ ){
                var P = pBOARD[k];
                if( P.FreeB>0 ){
                    if( P.CancelB>0 && (P.CancelB & (1<<(sol_int81[k]-1))) > 0 )  errorB=true;
                    if( P.FixedNo>0 && P.FixedNo!=sol_int81[k] ) errorB=true;
                }
            }
            if( errorB ){
                Result += " ... error ...";
                ResultLong += "\n\n  ... error ..."; 
				extResult = ResultLong; 
            }
            return errorB;
        }
    }
}