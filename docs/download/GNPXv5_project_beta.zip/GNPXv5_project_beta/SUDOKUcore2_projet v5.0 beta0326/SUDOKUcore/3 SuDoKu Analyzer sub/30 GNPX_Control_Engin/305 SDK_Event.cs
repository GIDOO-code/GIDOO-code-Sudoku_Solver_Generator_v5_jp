﻿using System;
using static System.Diagnostics.Debug;

namespace GNPXcore{
    public delegate void SDKEventHandler( object sender, SDKEventArgs args );

    public class SDKEventArgs: EventArgs{
	    public string eName;
	    public int    ePara0;
        public int    ePara1;
        public bool   Cancelled;
        public int[]  SDK81;

	    public SDKEventArgs( string eName=null, int ePara0=-1, int ePara1=-1, bool Cancelled=false ){
            try{
		        this.eName = eName;
		        this.ePara0 = ePara0;
                this.ePara1 = ePara1;
                this.Cancelled = Cancelled;
            }
            catch( Exception ex ){ WriteLine( $"{ex.Message}\r{ex.StackTrace}"); }
	    }
        public SDKEventArgs( int[] SDK81 ){
            this.SDK81=SDK81;
        }
    }
}