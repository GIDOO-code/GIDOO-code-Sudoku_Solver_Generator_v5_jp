using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Text;
using System.Linq;
using System.Collections;
using static System.Diagnostics.Debug;
using System.Xml.Serialization;

using GIDOO_space;
using GNPXcore.Properties;

namespace GNPXcore {
    //ALS(Almost Locked Set) 
    // ALS is a state where there are "n+1 candidate digits" in "n cells" belonging to the same house. 
    // https://gidoo-code.github.io/Sudoku_Solver_Generator_v5/page26.html

    [Serializable]

    public class UAnLS: IComparable{
        static private UInt128 qZero  = UInt128.Zero;
        static private UInt128 qOne   = UInt128.One; 

		static public  AnalyzerBaseV2 qAnalyzer;
        static public UInt128[]    pHouseCells81{ get{ return AnalyzerBaseV2.HouseCells81; } }
        static public UInt128[]    pConnectedCells81{ get{ return AnalyzerBaseV2.ConnectedCells81; } }

        static private protected bool _withID_=false;
        static public void Set_withID_( bool withID ) => _withID_ = withID;  // for DEBUG 

        public int               ID;
        public readonly int      Size;          //CellsSize 
        public readonly int      FreeB;         //ALS element digits
        public readonly int      Level;         //FreeDigits-CellsSize
        public readonly List<UCell> UCellLst = new List<UCell>();    //ALS Cells
		public readonly long     hashValue;
        protected readonly int   sortkey;       
     
		private UInt128[]		_connectedCellsB81_9;
		public UInt128[]		connected81_9 => _connectedCellsB81_9?? (_connectedCellsB81_9 = Create_connectedCellsB81_9() );
        public UInt128          connectedCellsB81;   


        public UInt128          bitExp;
        private UInt128[]       _BitExp9;           // <- B981in
        public UInt128[]        BitExp9 => _BitExp9?? (_BitExp9=UCellLst.Create_bitExp81_9() );

        public int              rcbFrame = 0x7FFFFFF;    //bit expression of ALS
      
        public int              rcbRow{ get=> rcbFrame&0x1FF; }      //row expression
        public int              rcbCol{ get=> (rcbFrame>>9)&0x1FF; } //column expression
        public int              rcbBlk{ get=> (rcbFrame>>18)&0x1FF; }//block expression

		public bool				IsInsideBlock => rcbBlk.BitCount()==1;

        public int              houseNo_Row{ get => (rcbRow.BitCount()==1)? rcbRow.BitToNum(): -1; }
        public int              houseNo_Col{ get => (rcbCol.BitCount()==1)? rcbCol.BitToNum()+9: -1; }
        public int              houseNo_Blk{ get => (rcbBlk.BitCount()==1)? rcbBlk.BitToNum()+18: -1; }

		// ------------------------------------------------
		private int[]		   _rcbAnd9;
		public int[]		   rcbAnd9 => _rcbAnd9?? (_rcbAnd9=Create_rcbAnd9());
		public int[]  Create_rcbAnd9(){ 
			int[] _rcbAnd9Tmp = new int[9]; 
			for( int no=0; no<9; no++ )  _rcbAnd9Tmp[no] = Create_rcbAnd9(no);
			return _rcbAnd9Tmp;
		}
		public int  Create_rcbAnd9( int no ){
			int noB=1<<no;
			int rcbAnd = UCellLst.Where(p=>(p.FreeB&noB)>0).						// Select cells with no as an element.
						 Aggregate(0x7FFFFFF, (a,b) => a & b.rc.rcbFrame_Value() );		// house(rcb) common to all elements.
			if( rcbAnd==0x7FFFFFF ) return 0;
			return rcbAnd;
		}
		// ------------------------------------------------

        public int              FreeBwk;         // changed during analysis
        public int[]            rcbBitExp9And; 
        public int[]            rcbBitExp9Or; 

        public bool             ALSenabled=true;

        public bool             LimitF=false;       
        public List<int>        LockedNoDir;

        public UAnLS            preALS = null;   // Use when creating a chain network.
        public int              RCClink
;           
        public UInt128          connectedCellsB;

        public UAnLS(){ }

		public long		Get_HashValue() => UCellLst.Aggregate( (long)0, (a,b) => a^b.Get_hashValue() );
	  //private int		Func_rcbFrame(UCell P)  => 1<<(P.b+18) | 1<<(P.c+9) | (1<<P.r);

        public UAnLS( int ID, int FreeB, List<UCell> UCellLst ){
            this.ID        = ID;
            this.Size      = UCellLst.Count;
            this.FreeB     = FreeB;
            this.UCellLst  = UCellLst;
            this.Level     = FreeB.BitCount()-Size;
            this.sortkey   = this.FreeB._SortKey();
			this.hashValue = Get_HashValue();

            // --- initialSettings ---
            this.bitExp    = this.UCellLst.Aggregate( UInt128.Zero, (p,q) => p | qOne<<q.rc );
            this.connectedCellsB = UCellLst.Aggregate( UInt128.Zero, (p,q) => p | pConnectedCells81[q.rc] );
            this.LockedNoDir = null;         
            Set_BitExpression( );
        }

        public void Set_BitExpression( ){
            FreeBwk = 0;
			rcbFrame = 0;
			//if( UCellLst.Count>2 ) WriteLine("");
            UCellLst.ForEach( P =>{
                FreeBwk  |= P.FreeB;
                rcbFrame |=	P.rcbFrame;		//Func_rcbFrame(P);
                foreach( int no in P.FreeB.IEGet_BtoNo() )  BitExp9[no] |= qOne<<P.rc;
				//if( UCellLst.Count>2 ) WriteLine( $"P{P}  rcbFrame:{rcbFrame.ToBitString27rcb()}" );
            } );

            rcbBitExp9And = new int[9];
            rcbBitExp9Or = new int[9];
            foreach( int no in FreeB.IEGet_BtoNo() ){
                rcbBitExp9And[no] = BitExp9[no].Ceate_rcbFrameAnd( );
                rcbBitExp9Or[no]  = BitExp9[no].Ceate_rcbFrameOr( );
            }
        }

		private UInt128[] Create_connectedCellsB81_9( ){			//..... FreeBwk
            UInt128[] B128 = new UInt128[9];
			foreach( int no in FreeB.IEGet_BtoNo() ){
				int noB = 1<<no;
				UInt128 Utmp = UInt128.MaxValue;
				foreach( var U in UCellLst ){
					if( (U.FreeB&noB) != 0 )  Utmp &= pConnectedCells81[U.rc];
				}
				B128[no] = Utmp;
			}
            return B128;
        }

		public int  rcbAnd9_wk( int no ){
			int noB=1<<no;
			int rcbAnd = UCellLst.Where(p=>(p.FreeBwk&noB)>0).						// Select cells with no as an element.
						 Aggregate(0x7FFFFFF, (a,b) => a & b.rc.rcbFrame_Value() );		// house(rcb) common to all elements.
			if( rcbAnd==0x7FFFFFF ) return 0;
				//UCellLst.ForEach( p=> WriteLine( $"b.rc:{p.rc.rcbFrame_Value().rcbToBitString27()}" ) );
				//WriteLine( $"rcbAnd:{rcbAnd.rcbToBitString27()}" );
			return rcbAnd;
		}

		public UInt128[] Get_ConnectedCellsB9( int noB9=0x1FF ){
			UInt128[] connectedCellsB9= new UInt128[9];
			foreach( int no in noB9.IEGet_BtoNo() ){
				connectedCellsB9[no] = BitExp9[no].IEGetRC().Aggregate(UInt128.Zero, (p,q)=> p| pConnectedCells81[q] );
			}
			return connectedCellsB9;
		}
        
        public bool IsPureALS(){
            //Pure ALS : not include locked set of proper subset
            if( Size<=2 ) return true;
            for( int sz=2; sz<Size-1; sz++ ){
                var cmb=new Combination(Size,sz);
                while(cmb.Successor()){
                    int fb=0;
                    for(int k=0; k<sz; k++ )  fb |= UCellLst[cmb.Index[k]].FreeB;
                    if( fb.BitCount()==sz ) return false;
                }
            }
            return true;
        }

		public void Copy_FreeBwk() => UCellLst.ForEach( p=> p.FreeBwk=p.FreeB );

        public int CompareTo( object obj ){  // for IComparable. ... don't delete
            UAnLS UB = obj as UAnLS;
            if( this.Level!=UB.Level ) return (this.Level-UB.Level);
            if( this.Size!=UB.Size )   return (this.Size-UB.Size);

            if( this.FreeB!=UB.FreeB ) return ( this.sortkey-UB.sortkey );

            int bitW = this.bitExp.CompareTo(UB.bitExp);
            if( bitW != 0 ) return bitW;

            return  0;
        }

        public override string ToString(){
            string st = $"UAnLS << ID:{ID} >>  [ Size:{Size} Level:{Level} ] ";
            st += $"  :{FreeB.ToBitString(9)}  FreeBwk:{FreeBwk.ToBitString(9)}\n";
            st += $" rcbFrame:{(rcbFrame).ToBitString27rcb()}";
			st += $" IsInsideBlock:{(IsInsideBlock? "@":"-")}";
            st += $"         bitExp:{bitExp.ToBitString81()}\n";
			st += $"connectedCellsB:{connectedCellsB.ToBitString81()}";

					//int rcbFX = 0;
            for(int k=0; k<UCellLst.Count; k++){
                st += "\n------";
				UCell P = UCellLst[k];
                st += $" rc:{P.rc.ToRCString()}";
                st += $" FreeB:{P.FreeB.ToBitString(9)}";
				st += $" FreeBwk:{P.FreeBwk.ToBitString(9)}";			               
				st += $" // rcbFrame: {P.rcbFrame.ToBitString27rcb(digitB:false)}";
            }
					//string stX1 = $"rcbFrame:{(rcbFrame).ToBitString27rcb()}";
					//string stX2 = $"rcbFrame:{(rcbFX).ToBitString27rcb()}";
					//WriteLine( $" stX1:{stX1}\n stX2:{stX2}" );

            return st;
        }
    }

}
