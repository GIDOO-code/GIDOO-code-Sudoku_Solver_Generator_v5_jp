using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Text;
using System.Linq;
using System.Collections;
using static System.Diagnostics.Debug;

using GIDOO_space;
using System.Xml.Linq;

namespace GNPXcore {
	// ========================================================
	//   In future versions, ULogical_Node -> ULogical_4_GN.
	// ========================================================

    public class ULogical_4_GN: IComparable{   // Logical Unit Element
		static private readonly ulong _ulong_1 = (ulong)1;
		
		static private readonly int[] _no1List; 
        static private readonly UInt128 _b9  = 0x1FF;
        static private readonly UInt128 _b1  = 1;
        static private readonly UInt128 _filterAll  = UInt128.MaxValue;

		static private UInt128  _BitGen_( int sPoint, int lng ) => ((UInt128.One<<(lng))-1)  << sPoint;

        static private readonly UInt128 _filter_b081   = _BitGen_(0,81);				//b081     0 -  80 (81)
        static private readonly UInt128 _filter_noB9   = _BitGen_(81,9);				//no      81 -  89 (9)

		static private readonly UInt128 _filter_RCBNf  = _BitGen_(81,36);				//frame   81 - 108 (36)

		static private readonly UInt128 _filter_frame  = _BitGen_(90,27);				//frame   90 - 108 (27)
		static private readonly UInt128 _filter_Rframe = _BitGen_(90,9);				//row     90 -  98 (9)
		static private readonly UInt128 _filter_Cframe = _BitGen_(99,9);				//column  99 - 107 (9)
		static private readonly UInt128 _filter_Bframe = _BitGen_(108,9);				//block  108 - 116 (9)

        static private readonly UInt128 _filter_b081R  = _filter_b081^_filterAll;
        static private readonly UInt128 _filter_noB9R  = _filter_noB9^_filterAll;

		static private readonly UInt128 _filter_RCBNfR  = _filter_RCBNf^_filterAll;

		static private readonly UInt128 _filter_frameR  = _filter_frame^_filterAll;
		static private readonly UInt128 _filter_RframeR = _filter_Rframe^_filterAll;
		static private readonly UInt128 _filter_CframeR = _filter_Cframe^_filterAll;
		static private readonly UInt128 _filter_BframeR = _filter_Bframe^_filterAll;

		static private readonly UInt128 _filter_ID      = _BitGen_(0,32);				//ID       0 -  31 (32) 
		static private readonly UInt128 _filter_house   = _BitGen_(32,27);				//house   32 -  58 (27)
		static private readonly UInt128 _filter_lkType  = _BitGen_(59,3);				//lkType  59 -  59 (3)
																					 
		static private readonly UInt128 _filter_IDR    = _filter_ID^_filterAll;	
		static private readonly UInt128 _filter_houseR = _filter_house^_filterAll;
		static private readonly UInt128 _filter_lkTypeR = _filter_lkType^_filterAll;	//house   32 -  58 (2)

		static private readonly UInt128 _filter_90    = _BitGen_(0,90);

		// ===== Container ========================================================
        private UInt128 LNval_A=0;		// b081(81), noB9(9), rcbFrame(27)
		private UInt128 LNval_B=0;		// ID(32), house(27), lkType(3)



		// ===== Property ========================================================
        public UInt128 b081{     get=> LNval_A&_filter_b081;                  set=> LNval_A= (LNval_A&_filter_b081R) | (value & _filter_b081); }


		public int     noB9{     get=> (int)(LNval_A>>81)&0x1FF;			  set=> LNval_A= (LNval_A&_filter_noB9R) | ( ((UInt128)value<<81) & _filter_noB9); }
		
        public int     rcbFrame{ get=> (int)((LNval_A&_filter_frame)>>90);    set=> LNval_A= (LNval_A&_filter_frameR) | ( ((UInt128)value<<90) & _filter_frame); }
		public long    rcbnFrame{get=> (long)((LNval_A&_filter_RCBNf)>>81);    set=> LNval_A = (LNval_A&_filter_RCBNfR) | ( ((UInt128)value<<81) & _filter_RCBNf); }
		public UInt128 b90{      get=>  LNval_A&_filter_90; }		// (b90+noB9)
 //     public UInt128 matchKey => b90;	
		
		public int     ID{       get=> (int)(LNval_B&_filter_ID);			  set=> LNval_B= (LNval_B&_filter_IDR) | ( ((UInt128)value) & _filter_ID);  }
		
		public int     houseB{   get=> (int)((LNval_B&_filter_house)>>32);	  set=> LNval_B= (LNval_B&_filter_houseR) | ( (((UInt128)value)<<32) & _filter_house);  }
		public int     lkType{   get=> (int)((LNval_B&_filter_lkType)>>59);	  set=> LNval_B= (LNval_B&_filter_lkTypeR) | ( (((UInt128)value)<<59) & _filter_lkType);  }
		
		public int     b081_BCount=-1;
		public int     noB9_BCount=-1;

	// ===== Constracter ========================================================
		static ULogical_4_GN(){  // static
			_no1List = new int[512];
			for( int n=0; n<512; n++ ) _no1List[n] = n.BitToNum();
		}
			
        //public ULogical_4_GN( ){ }   // b081=(UInt128)77; no=10; pmCnd=3; }	<-- for DEBUG
        public ULogical_4_GN( int noB9, UInt128 b081, int houseB, int lkType, int ID=0 ){  
 			this.noB9 = noB9;  	
			this.b081 = b081;
			this.b081_BCount = b081.BitCount();
			this.noB9_BCount = noB9.BitCount();
			this.houseB = houseB;
			this.lkType = lkType;
			this.ID = ID;
			this.rcbFrame = b081.Ceate_rcbFrameOr();  // Generate rcb frame in constructor
		}
	// --------------------------------------------------------------------------


        public int CompareTo( object obj ){
            var Xobj = obj as ULogical_4_GN;
            if( Xobj is null  )  return -1;
            var dif = this.LNval_A-Xobj.LNval_A;
            int ret = (dif<0)? -1: (dif>0)? 1: 0;
            return ret;
        }

		public int CompareToA( ULogical_4_GN B ){
            var Xobj = B as ULogical_4_GN;
            if( Xobj is null  )  return -1;
			if( this.noB9 !=B.noB9 )  return (this.noB9-B.noB9);
            if( this.b081 == B.b081 ) return 0;
            return (this.b081<B.b081)? -1: +1;
        }

        public override int GetHashCode(){
            int hashValue = LNval_A.GetHashCode();  // <-- (b081,no,pmCnd)
            return hashValue;
        }

        public override string ToString(){
			string st1 = $" ID:{ID:000} {ToString_SameHouseComp().PadRight(12)}#{noB9.ToBitString(9)}";
			string st2 = $"  lkType:{lkType} houseB:{houseB.rcbToBitString27()}";
			string st = $" {st1}  rc:{b081.ToBitString81()} rcb:{rcbnFrame.ToBitString36rcbn(digitB:false)}" ;
			st += $" {st2}";
            return st;
        }

//      static public string ToBitString27rcb( this uint num, bool digitB=true ){
//		static public string ToBitString36rcbn( this ulong Lnum, bool digitB=true ){
/*
					public string ToStringA(){
					  //string stIDno = $"ID:{ID:0000} no:#{no+1} {ToString_pmCnd()}";
						string st_IDno = $"ID:{ID:0000} no:#{noB9.ToBitStringN(9).PadRight(5)} {ToString_pmCnd()}  ";
						string st_rc   = $"rc:{ToString_SameHouseComp().PadRight(13)} {b081.ToBitString81N()}";
						string st_noB9 = $" {noB9.ToBitString(9)}";
						return (st_IDno+st_rc+st_noB9);
					}
					public string ToStringB(){
						string stID = $"ID:{ID:000}";
						string strc = $" rc:{ToString_SameHouseComp().PadRight(17)} {b081.ToBitString81()}";
						string stno = $" no:#{noB9.ToBitStringN(9)}";

						return (stID+strc+stno);
					}
*/
	

        public string ToString_SameHouseComp(){
            string st = $"{ToRCBString().ToString_SameHouseComp()}";
            return st.Trim();
        }

        public string ToRCBString(){
            string st="";
            for(int n=0; n<3; n++){
                int bp = (int)( b081 >> (n*27) );
                for(int k=0; k<27; k++){
                    if((bp&(1<<k))==0)  continue;
                    int rc=n*27+k;
                    st += $" {rc.ToRCString()}";
                }
            }
            return st.Trim();
        }

		public string HouseToString(){
			string st="";
			if( lkType==1 )	st = houseB.HouseToString();	//inter cells
			if( lkType==2 )	st = b081.FindFirst_rc().ToRCString(); ;	//cell
			st += "#" + noB9.ToBitStringN(9);
				//WriteLine( st );
			return st;
		}

        // ============= ULgElement_test =============
            // [ToDo] migrate to unit test project.
        static public void ULogical_4_GN_test(){

			//--------------------------------------------------------------------------------
			WriteLine( $"\n _BitGen_" ); 
			for( int sp=0; sp<128; sp+=20 ){
				for( int n=1; n<=20; n++ ){
					UInt128 val = _BitGen_(sp,n);
					WriteLine( $" sp:{sp:000}  n:{n:00}  val:{val.ToBitString128()}" );
				}
			}

			for( int sp=0; sp<128; sp+=20 ){
				for( int n=1; n<=81; n++ ){
					UInt128 val = _BitGen_(sp,n);
					WriteLine( $" sp:{sp:000}  n:{n:00}  val:{val.ToBitString128()}" );
				}
			}
			//--------------------------------------------------------------------------------
			WriteLine( "\nULogical_4_GN_test" );
            WriteLine( $"  _filter_b081 : {_filter_b081.ToBitString128()}" );
            WriteLine( $"  _filter_b081R: {_filter_b081R.ToBitString128()}" );
            WriteLine( $"  _filter_noB9 : {_filter_noB9.ToBitString128()}" );
            WriteLine( $"  _filter_noB9R: {_filter_noB9R.ToBitString128()}" );

			WriteLine( "" );
            WriteLine( $" _filter_frame : {_filter_frame.ToBitString128()}" );
            WriteLine( $"_filter_frameR : {_filter_frameR.ToBitString128()}" );
			WriteLine( $" _filter_frame : {_filter_RCBNf.ToBitString128()}" );
            WriteLine( $"_filter_frameR : {_filter_RCBNfR.ToBitString128()}" );

            WriteLine( $" _filter_Rframe: {_filter_Rframe.ToBitString128()}" );
			WriteLine( $"_filter_RframeR: {_filter_RframeR.ToBitString128()}" );

            WriteLine( $" _filter_Cframe: {_filter_Cframe.ToBitString128()}" );
			WriteLine( $"_filter_CframeR: {_filter_CframeR.ToBitString128()}" );

            WriteLine( $" _filter_Bframe: {_filter_Bframe.ToBitString128()}" );
            WriteLine( $"_filter_BframeR: {_filter_BframeR.ToBitString128()}" );

			WriteLine( "" );
            WriteLine( $"    _filter_ID :  {_filter_ID.ToBitString128()}" );       
            WriteLine( $"   _filter_IDR :  {_filter_IDR.ToBitString128()}" );
            WriteLine( $" _filter_house :  {_filter_house.ToBitString128()}" );       
            WriteLine( $"_filter_houseR :  {_filter_houseR.ToBitString128()}" );
   
            WriteLine( $"    _filter_90 :  {_filter_90.ToBitString128()}" );

			Random rnd = new Random();
			bool IsPerfectB = true;
            int  id=0, h=0, noB9=0, ID=0;
            for( int rc=0; rc<81; rc++ ){    
                string st = "";
                for( int no=0; no<9; no++ ){
						id = (++id)%7; // 23 
						int house = 1<<((++h)%27);
						noB9 = 1<<no;

						UInt128 ub = (UInt128)1<<rc;
                    ULogical_4_GN BB = new ULogical_4_GN( noB9, ub, house, id);
						st += $" {BB} /";

                    ULogical_4_GN BB2 = new ULogical_4_GN(BB.noB9,BB.b081,house,BB.ID);   
		  				WriteLine( BB2.LNval_A.ToBitString128() );
						if( noB9!=BB2.noB9 || ub!=BB2.b081 ){ IsPerfectB=false; WriteLine( $"{BB} {BB2}  <-- error" ); }
						WriteLine( BB2 );
                }
                WriteLine( $"{st}" ); 
            }  
	
			         
			for( int rc=0; rc<81; rc++ ){    
                string st = "";
                for( int no=0; no<9; no++ ){				
						noB9=1<<no; 
						UInt128 ub = (UInt128)1<<rc;
						h = (++h)%27; 
						int houseB = 1<<h;
						id = (++id)%7;
					ULogical_4_GN BB3 = new( noB9, ub, houseB, id );
						WriteLine( $"{BB3.LNval_A.ToBitString128()}  BB3" );
						if( noB9!=BB3.noB9 ){   IsPerfectB=false;  WriteLine( $"no:{no} BB3.no:{BB3.noB9.ToBitString(9)} ...error" ); }
						if( id!=BB3.ID ){       IsPerfectB=false;  WriteLine( $"ID:{id} BB3.id:{BB3.ID} ...error" ); }
						if( houseB!=BB3.houseB ){ IsPerfectB=false;  WriteLine( $"house:{houseB} BB3.no:{BB3.houseB} ...error" );  }

					int noB = rnd.Next(511);
					BB3.noB9 = noB;
							if( noB!=BB3.noB9 ){ IsPerfectB=false; WriteLine( $" rc:{rc} no:{no} no:{noB.ToBitString(9)} BB3.no:{BB3.noB9.ToBitString()} ...error" ); }
                }       
                WriteLine( $"{st}" ); 
            } 

			WriteLine( $" *** IsPerfectB : {IsPerfectB}") ;
        }
    }

}
