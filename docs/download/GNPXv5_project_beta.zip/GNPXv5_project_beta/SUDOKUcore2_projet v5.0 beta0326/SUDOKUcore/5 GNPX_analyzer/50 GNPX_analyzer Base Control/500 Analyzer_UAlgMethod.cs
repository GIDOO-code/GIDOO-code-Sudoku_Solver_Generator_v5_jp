using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Windows.Media;
using System.Threading;
using static System.Diagnostics.Debug;
using static System.Math;
using System.Security.Cryptography;
using System.Windows.Interop;
using System.IO;
using System.Text;

namespace GNPXcore{
    using pRes=Properties.Resources;
    public delegate bool dSolver();

    // *==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*==*
    public class UAlgMethod{
        static private int ID0=0;
        public int        ID;               // System default order.
        public int        recm;
        public string     MethodName;
        public string     MethodKey => ID.ToString().PadLeft(7) +DifLevel.ToString().PadLeft(2) +MethodName;

        // For algorithms with negative levels, there are simpler conjugate algorithms.
        // If you just solve Sudoku, you don't need it. For example, the 5D-LockedSet is conjugate with the 4D-LockedSet.
        public int        DifLevel;         // Level of difficulty
        public dSolver    Method;
        public bool       GenLogB;          // "GeneralLogic"
        public int        UsedCC=0;         // Counter applied to solve one puzzle.
        public bool       IsChecked=true;   // Algorithm valid

        public UAlgMethod( ){ }
        public UAlgMethod( int pid, int recm, string MethodName, int DifLevel, dSolver Method, bool GenLogB=false ){
            this.ID         = pid*1000+(ID0++); //System default order.
            this.recm       = recm;   
            this.MethodName = MethodName;
            this.DifLevel   = DifLevel;     //Level of difficulty
            this.Method     = Method;
            this.GenLogB    = GenLogB;
        }
        public override string ToString(){
            string st=MethodName.PadRight(30)+"["+DifLevel+"]"+" "+UsedCC;
            st += "GeneralLogic:"+GenLogB.ToString();
            return st;
        }
    }
}