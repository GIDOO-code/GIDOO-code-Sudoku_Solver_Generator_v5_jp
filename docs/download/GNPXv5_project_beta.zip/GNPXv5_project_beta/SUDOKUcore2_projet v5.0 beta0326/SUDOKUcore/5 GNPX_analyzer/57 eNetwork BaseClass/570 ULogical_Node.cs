using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Text;
using System.Linq;
using System.Collections;
using static System.Diagnostics.Debug;

using GIDOO_space;
using System.Xml.Linq;

namespace GNPXcore {

    public class ULogical_Node: IComparable{   // Logical Unit Element
		static private readonly ulong _ulong_1 = (ulong)1;
		
		static private readonly int[] _no1List; 
        static private readonly UInt128 _b9  = 0x1FF;
        static private readonly UInt128 _b1  = 1;
        static private readonly UInt128 _filterAll  = UInt128.MaxValue;


        static private readonly UInt128 _filter_b081  = (UInt128.One<<81)-1;         //b081    0 -  80 (81)
        static private readonly UInt128 _filter_no    = (UInt128)0xF<<81;            //no     81 -  84 (4)
        static private readonly UInt128 _filter_pmCnd = UInt128.One<<85;             //pmCnd  85 -  85 (1)
        static private readonly UInt128 _filter_used  = UInt128.One<<86;             //used   86 -  86 (1)
        static private readonly UInt128 _filter_ID    = ((UInt128.One<<28)-1)<<100;  //ID    100 - 127 (28) 

        static private readonly UInt128 _filter_b086   = (UInt128.One<<86)-1;

        static private readonly UInt128 _filter_b081R  = _filter_b081^_filterAll;
        static private readonly UInt128 _filter_noR    = _filter_no^_filterAll;
        static private readonly UInt128 _filter_pmCndR = _filter_pmCnd^_filterAll;
        static private readonly UInt128 _filter_usedR  = _filter_used^_filterAll;
        static private readonly UInt128 _filter_IDR    = _filter_ID^_filterAll;

		static ULogical_Node(){
			_no1List = new int[512];
			for( int n=0; n<512; n++ ) _no1List[n] = n.BitToNum();
		}

	// ==============================================================================================

        public UInt128 LNval=0;   // <<< >>>

        public UInt128 b081{  get=> LNval&_filter_b081;          set=> LNval= (LNval&_filter_b081R) | (value&_filter_b081); }
		public UInt128 b086{  get=> LNval&_filter_b086; }

        public int     no{    get=> (int)(LNval>>81)&0xF;        set=> LNval= (LNval&_filter_noR) | (((UInt128)(value&0xF))<<81); }
        public int     pmCnd{ get=> (int)(LNval>>85)&0x1;        set=> LNval= (LNval&_filter_pmCndR) | (((UInt128)(value&0x1))<<85); }
        public int     used{  get=> (int)(LNval>>86)&0x1;        set=> LNval= (LNval&_filter_usedR) | (((UInt128)(value&0x1))<<86); } 
        public int     ID{    get=> (int)(LNval>>100)&0x7FFFFFF; set=> LNval= (LNval&_filter_IDR) | (((UInt128)(value&0x7FFFFFF))<<100); }

        public int     rc{    get=> b081.BitToNum(sz:81); }
        public int     rcno{  get=> rc<<4|no; }

		public ulong   rcbnoFrame(){ return (_ulong_1<<(no+27)) | (ulong)(b081.Ceate_rcbFrameOr()); }
		public int	   rcbFrame{ get => b081.Ceate_rcbFrameOr(); }// (1<<(rc.ToBlock()+18)) | (1<<(rc%9+9)) | (1<<rc/9); }

        public int     nopmCnd{ get=> (int)(LNval>>81)&0x1F; }
        public int     bpTNO{ get => 1<<(no + pmCnd*9); } 
        public int     Size{ get => b081_BitCount; }
	
        public UInt128 matchKey2;		// matchKey2( this UInt128 val )  => val & _filter0085; //b081, no
		public UInt128 matchKey3;		// matchKey3( this UInt128 val )  => val & _filter0086; //b081, no, pmCnd


        public bool    LogicallyConnected( ULogical_Node ULG ) =>
            (this.pmCnd==0)? (ULG.nopmCnd==this.nopmCnd && (ULG.b081&this.b081)>UInt128.Zero):
                             (ULG.nopmCnd==this.nopmCnd && ULG.b081.DifSet(this.b081)==UInt128.Zero);

        public string  TFmark => (pmCnd==1)? "+": "-";


		public ULogical_Node( ){ }   // b081=(UInt128)77; no=10; pmCnd=3; } <-- for DEBUG
        public ULogical_Node( int no, int rc, int pmCnd, int ID=0 ){ 
            LNval = keyDef( no, rc, pmCnd, ID );
            matchKey2 = LNval.matchKey2();
			matchKey3 = LNval.matchKey3();
        }
        static public UInt128 keyDef( int no, int rc, int pmCnd, int ID=0 ){
            UInt128 v =  ((UInt128)(ID&0x7FFFFFFF)<<100) | ((UInt128)(pmCnd&0x1)<<85) | 
						 (((UInt128)(no&0xF))<<81) | ((_b1<<rc)&_filter_b081);
            return v;
        }

        public ULogical_Node( int no, UInt128 b081, int pmCnd, int ID=0 ){ 
            LNval = keyDef( no, b081, pmCnd, ID );
            matchKey2 = LNval.matchKey2();
			matchKey3 = LNval.matchKey3();
        }
        static public UInt128 keyDef( int no, UInt128 b081, int pmCnd, int ID=0 ){
            UInt128 v =  ((UInt128)(ID&0x7FFFFFFF)<<100) | ((UInt128)(pmCnd&0x1)<<85) | 
						 ((UInt128)(no&0xF)<<81) | (b081&_filter_b081);
            return v;
        }


        public int b081_BitCount => b081.BitCount();

        public int b081_FindFirst_rc(){
            UInt128 w = b081;
            for( int rc=0; rc<81; rc++ ){
                if( (w&_b9) == 0 ){ w>>=9; rc+=8; continue;}
                if( (w&_b1)>0 )  return rc;
                w >>= 1;
            }

            return -1;
        }

        public int CompareTo( object obj ){
            var Xobj = obj as ULogical_Node;
            if( Xobj is null  )  return -1;
            var dif = this.LNval-Xobj.LNval;
            int ret = (dif<0)? -1: (dif>0)? 1: 0;
            return ret;
        }

		public int CompareToA( ULogical_Node B ){
            var Xobj = B as ULogical_Node;
            if( Xobj is null  )  return -1;
			if( this.no !=B.no )  return (this.no-B.no);
            if( this.b081 == B.b081 ) return 0;
            return (this.b081<B.b081)? -1: +1;
        }

        public override int GetHashCode(){
            int hashValue = (LNval&_filter_b086).GetHashCode();  // <-- (b081,no,pmCnd)
            return hashValue;
        }

        public override string ToString(){
            string st = $"{ToString_SameHouseComp()}#{no+1}{ToString_pmCnd()}";
            if( ID>0 )  st += $" {ID}";
            return st;
            
            string ToString_pmCnd() => ( (pmCnd==1)? "+": (pmCnd==0)? "-": "*");
        }

		public string ToStringA(){
			string stIDno = $"ID:{ID:0000} no:#{no+1} {ToString_pmCnd()}";
			string strc = $"rc:{ToString_SameHouseComp().PadRight(18)} {b081.ToBitString81()}";

            return (stIDno+strc);
            
            string ToString_pmCnd() => ( (pmCnd==1)? "+": (pmCnd==0)? "-": "*");
        }
		public string ToStringB(){
			string stID = $"ID:{ID:0000}";
			string strc = $" rc:{ToString_SameHouseComp().PadRight(18)} {b081.ToBitString81()}";
			string stno = $" no:#{no+1}";

            return (stID+strc+stno);
            
            string ToString_pmCnd() => ( (pmCnd==1)? "+": (pmCnd==0)? "-": "*");
        }



        public string ToString_SameHouseComp(){
            string st = $"{ToRCBString().ToString_SameHouseComp()}";
            return st.Trim();
        }

        public string ToRCBString(){
            string st="";
            for(int n=0; n<3; n++){
                int bp = (int)( b081 >> (n*27) );
                for(int k=0; k<27; k++){
                    if((bp&(1<<k))==0)  continue;
                    int rc=n*27+k;
                    st += $" {rc.ToRCString()}";
                }
            }
            return st.Trim();
        }


        // ============= ULgElement_test =============
            // [ToDo] migrate to unit test project.
        static public void ULgElement_test(){

            WriteLine( $"  _filter_b081 : {_filter_b081.ToBitString128()}" );
            WriteLine( $"  _filter_b081R: {_filter_b081R.ToBitString128()}" );
            WriteLine( $"    _filter_no : {_filter_no.ToBitString128()}" );
            WriteLine( $"    _filter_noR: {_filter_noR.ToBitString128()}" );
            WriteLine( $" _filter_pmCnd : {_filter_pmCnd.ToBitString128()}" );
            WriteLine( $" _filter_pmCndR: {_filter_pmCndR.ToBitString128()}" );
            WriteLine( $"  _filter_used : {_filter_used.ToBitString128()}" );
            WriteLine( $"  _filter_usedR: {_filter_usedR.ToBitString128()}" );
            WriteLine( $"    _filter_ID : {_filter_ID.ToBitString128()}" );       
            WriteLine( $"   _filter_IDR : {_filter_IDR.ToBitString128()}" );

			Random rnd = new Random();
			bool IsPerfectB = true;
            int pm=0, id=0, used=0, house=0;
            for( int rc=0; rc<81; rc++ ){    
                string st = "";
                for( int no=0; no<9; no++ ){
                    pm = (++pm)%2;
                    id = (++id)%7; // 23 
                    used = 1-used;
					house = (++house)%27;

                    // class object definition, ToString()
                    UInt128 ub = (UInt128)1<<rc;
                    ULogical_Node BB = new ULogical_Node(no,ub,pm,id);
                    st += $" {BB} /";

                    // class object definition, getter, value match.
                    ULogical_Node BB2 = new ULogical_Node(BB.no,BB.b081,BB.pmCnd,BB.ID);   
					WriteLine( BB2.LNval.ToBitString128() );
                    if( no!=BB2.no || ub!=BB2.b081 || pm!=BB2.pmCnd ){ IsPerfectB=false; WriteLine( $"{BB} {BB2}  <-- error" ); }

                    // defining a no-argument object, setter
                    ULogical_Node BB3 = new ULogical_Node();
                    BB3.no=no; BB3.b081=ub; BB3.pmCnd=pm; BB3.ID=id; BB3.used=used;
                    if( no!=BB3.no ){ IsPerfectB=false;    WriteLine( $"no:{no} BB3.no:{BB3.no} ...error" ); }
                    if( id!=BB3.ID ){ IsPerfectB=false;    WriteLine( $"ID:{id} BB3.id:{BB3.ID} ...error" ); }
                    if( pm!=BB3.pmCnd ){ IsPerfectB=false;  WriteLine( $"ttf::{pm} BB3.pmCnd:{BB3.pmCnd} ...error" ); }
                    if( used!=BB3.used ){ IsPerfectB=false;  WriteLine( $"used:{used} BB3.no:{BB3.used} ...error" );  }

					int noB = (int)rnd.NextInt64(9);
					BB3.no = noB;
					if( noB!=BB3.no ){ IsPerfectB=false; WriteLine( $" rc:{rc} no:{no} no:{noB.ToBitString(9)} BB3.no:{BB3.no.ToBitString()} ...error" ); }
                //    if( no!=BB3.no | ub!=BB3.b081 || pm!=BB3.pmCnd || id!=BB3.ID || used!=BB3.used ){
                //        WriteLine( $"{BB} {BB2} {BB3} ID:{id} used:{used} <-- error" );
                //    }

                 //   WriteLine( $"{BB} {BB2} {BB3}" );
                }       
                WriteLine( $"{st}" ); 
            }  
			
			WriteLine( $" *** IsPerfectB : {IsPerfectB}") ;
        }
    }

}
